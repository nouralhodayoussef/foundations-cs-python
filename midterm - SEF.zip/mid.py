import csv
import os
import datetime

# I used "https://realpython.com/python-csv/" && "https://docs.python.org/3/library/os.html" as sources


# Function to read tickets from the text file and import them into the special list
def import_tickets():
    tickets = []
    file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tickets.txt')
    with open(file_path, 'r') as file:
        reader = csv.reader(file)
        for row in reader:
            ticket ={
                'ticket_id': row[0],
                'event_id': row[1],
                'username': row[2],
                'timestamp': row[3],   
                'priority': int(row[4])
            }
            tickets.append(ticket)
    return tickets

# Function to verify the username and password and determine the user type
def login():
    attempts = 0
    max_attempts = 5

    while attempts < max_attempts:
        username = input("Username: ")
        password = input("Password: ")

        if username == "admin" and password == "admin123123":
            return "admin"
        elif password == "":
            return "normal"
        else:
            print("Incorrect Username and/or Password.")
            attempts += 1

    print("Maximum login attempts reached. Exiting...")
    return None


# Function to display the admin menu options and get user input
def admin_menu():
    print("\nAdmin Menu:")
    print("1. Display Statistics")
    print("2. Book a Ticket")
    print("3. Display all Tickets")
    print("4. Change Ticket's Priority")
    print("5. Disable Ticket")
    print("6. Run Events")
    print("7. Exit")

    choice = input("Enter your choice (1-7): ")
    return choice

# Function to display the normal user menu options and get user input
def user_menu():
    print("\nUser Menu:")
    print("1. Book a Ticket")
    print("2. Exit")

    choice = input("Enter your choice (1-2): ")
    return choice

# Function to display statistics (event ID with highest number of tickets)
def display_statistics(tickets):
    event_counts = {}
    for ticket in tickets:
        event_id = ticket['event_id']
        if event_id in event_counts:
            event_counts[event_id] += 1
        else:
            event_counts[event_id] = 1

    max_event_id = max(event_counts, key=event_counts.get)
    print(f"Event ID with highest number of tickets: {max_event_id}")

# Function to book a new ticket for an event
def book_ticket(tickets):
    ticket_id = len(tickets) + 1
    event_id = input("Enter event ID: ")
    username = input("Enter username: ")
    timestamp = input("Enter timestamp (YYYYMMDD): ")
    priority = int(input("Enter priority: "))

    ticket = {'ticket_id': ticket_id, 'event_id': event_id, 'username': username, 'timestamp': timestamp, 'priority': priority}
    tickets.append(ticket)
    print("Ticket booked successfully.")

# Function to display all tickets ordered by date and event ID
def display_tickets(tickets):
    today = datetime.datetime.today().strftime('%Y%m%d')
    sorted_tickets = sorted(tickets, key=lambda x: (x['timestamp'], x['event_id']))
    for ticket in sorted_tickets:
        if ticket['timestamp'] >= today:
            print(f"Ticket ID: {ticket['ticket_id']}, Event ID: {ticket['event_id']}, Username: {ticket['username']}, Timestamp: {ticket['timestamp']}, Priority: {ticket['priority']}")

# Function to change the priority of a ticket
def change_priority(tickets):
    ticket_id = input("Enter ticket ID: ")
    priority = int(input("Enter new priority: "))

    found = False
    for ticket in tickets:
        if ticket['ticket_id'] == ticket_id:
            ticket['priority'] = priority
            found = True
            break

    if found:
        print("Priority changed successfully.")
    else:
        print("Ticket not found.")

# Function to disable a ticket
def disable_ticket(tickets):
    ticket_id = input("Enter ticket ID: ")

    found = False
    for ticket in tickets:
        if ticket['ticket_id'] == ticket_id:
            tickets.remove(ticket)
            found = True
            break

    if found:
        print("Ticket disabled successfully.")
    else:
        print("Ticket not found.")

# Function to run events and remove them from the list
def run_events(tickets):
    today = datetime.datetime.today().strftime('%Y%m%d')  # "https://stackoverflow.com/questions/32490629/getting-todays-date-in-yyyy-mm-dd-in-python"
    sorted_tickets = sorted(tickets, key=lambda x: (x['priority'], x['event_id']))

    events_today = [ticket for ticket in sorted_tickets if ticket['timestamp'] == today]

    if not events_today:
        print("No events scheduled for today.")
    else:
        print("Current events today:")
        for ticket in events_today:
            print(f"Event ID: {ticket['event_id']}, Priority: {ticket['priority']}")

    for ticket in events_today:
        tickets.remove(ticket)

# Main program
def main():
    tickets = import_tickets()
    user_type = login()

    if user_type == "admin":
        attempts = 1
        while attempts <= 5:
            choice = admin_menu()

            if choice == "1":
                display_statistics(tickets)
            elif choice == "2":
                book_ticket(tickets)
            elif choice == "3":
                display_tickets(tickets)
            elif choice == "4":
                change_priority(tickets)
            elif choice == "5":
                disable_ticket(tickets)
            elif choice == "6":
                run_events(tickets)
            elif choice == "7":
                break
            else:
                print("Invalid choice. Please try again.")


    elif user_type == "normal":
        while True:
            choice = user_menu()

            if choice == "1":
                book_ticket(tickets)
            elif choice == "2":
                break
            else:
                print("Invalid choice. Please try again.")
    else:
        print("Incorrect Username and/or Password.")

if __name__ == "__main__":
    main()